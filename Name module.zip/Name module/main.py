import greetings

greetings.greet("Alice")
